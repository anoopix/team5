﻿using System;

namespace DialougeStuff
{
    class Program
    {
        static void Main(string[] args)
        {


            Console.WriteLine("You awaken to the sound fo your alarm going off as a bit of sunlight enters your room.");
            Console.WriteLine("You look groggily over at the time...");
            Console.WriteLine("'CRAP, IM LATE TO SCHOOL'");
            Console.WriteLine("You hastily throw on some clothes, grab your school bag, and rush out of your house to school.");
            Console.WriteLine("Making sure not to forget that letter you are giving to your special someone.");
            Console.WriteLine("As you arrive at school, you make your way to your opening class.");
            //Console.WriteLine("")




            //Shark Boy/Jimmy A. Williams text stuff

            //Monday morning
            //Shark
            Console.WriteLine("'Huh, a letter? Fine I'll open it, but you need to stay right there runt!'");

            //Player Shark
            Console.WriteLine("'O-okay.'");

            //Narrator
            Console.WriteLine("Jimmy tears open the envelope, reading through the contents of the letter.");
            Console.WriteLine("You start to heat up with nervousness and anxiety as you see him read through your letter,");
            Console.WriteLine("though you swear you see him..... blush?");

            //Shark
            Console.WriteLine("'I... uh-*cough*, Fine, I will join you for dinner this friday-'");

            //inner thoughts
            Console.WriteLine("HOLYSHIT HOLYSHIT HOLYSHIT");

            //Shark
            Console.WriteLine("'but if you don't show me a great time, you'll be bird feed.'");

            //Monday evening/Every Evening
            Console.WriteLine("Where do you want to go to get ready for your date friday");
            Console.WriteLine("The Gym");
            Console.WriteLine("Restaurant");
            Console.WriteLine("Library");
            Console.WriteLine("Club");


            //this attribute is just so the if statment doesnt scream at me as I organize the chocies, change or delete it as needed
            int eveningChoice = 0;
            if (eveningChoice == 0)
            {
                Console.WriteLine("You decide to go to the Gym to make them gains.");
                //increase strength stat
            }
            else if (eveningChoice == 1)
            {
                Console.WriteLine("You go to your part time job at Big Tuna to make some cash.");
                //increase wealth stat
            }
            else if (eveningChoice == 2)
            {
                Console.WriteLine("You spend some time in the library becoming cultrued in all things fish related");
                //increase smarts stat
            }
            else if (eveningChoice == 3)
            {
                Console.WriteLine("You go to the local club to get your grove on.");
                //increase charm stat
            }

            //Tuesday Morning-Shark
            Console.WriteLine("'Hey, dude. Did you hear about hoe FETA helped exposed the horrid environment that sea cows live in?'");

            //Choices
            Console.WriteLine("'Yeah, its really horrible how they treat the food that we eat.'");//choice 1
            Console.WriteLine("'I mean, I don't think it really matters at all.'");//choice 2

            int choice=0;
            if (choice == 1)
            {
                Console.WriteLine("'Finally, someone who gets it! This is the reason why I decided to become a vegitarian.'");
                //affection ++
            }
            else if (choice == 2)
            {
                Console.WriteLine("'You really don't care what happens to those poor creatures!?'");
                //affection --
            }

            //Wednsday Morning-Shark
            Console.WriteLine("'Hey, I need to hide something from my old man, you know a good place to stash something until the heat cools down?'");

            //Chocies
            Console.WriteLine("'Bury it where those giant iron things drop in, your dad will never look there!'");//choice 1
            Console.WriteLine("'Go to the local warehouse and stash it in one of the crates there. You will be able to come back later for it.'");//choice 2

            if (choice == 1)
            {
                Console.WriteLine("'..... That's where my brother died......");
                //affection--
            }
            else if (choice == 2)
            {
                Console.WriteLine("'Thats a great spot! I hangout there all the time with my buddy Oscar!");
                //affection++
            }

            //Thursday Morning-Shark
            Console.WriteLine("'Hey, realized I haven't given you the required test to make sure you're up to snuf. So answer me this: What's more important,'");
            Console.WriteLine("'Beating up jackasses causing trouble, or taking care of a group of a group of guppies?'");

            //choices
            Console.WriteLine("'The guppies, anyone would say they would beat up the bad guys, but only the truely heroic would say they would save some guppies.'");//choice 1
            Console.WriteLine("'Always beat up the bad guys, if you don't, then your just a corward.'");//choice 2

            if(choice==1)
            {
                Console.WriteLine("'Exactly, we need more peopel that are willing to look out for the little guys in this town.'");
                //affection++
            }
            else if (choice == 2)
            {
                Console.WriteLine("'Damn right!'");
                //affection++
            }

            //Friday
            //Good End-Shark
            Console.WriteLine("'Hey, I had a great time... Let's keep this a regular thing between you and me!'");
            //Friend-zone end
            Console.WriteLine("This was fun hanging out, like friends. I know! Let's be best buds and just chill with one another, as friends!");
            //Good date, no feeling
            Console.WriteLine("'This was fun but..... I don't really want to be with anyone right now.'");
            //Real Bad End
            Console.WriteLine("'No. Go home. This will never happen.'");

        }
    }
}
